module.exports = {
    lintOnSave:false
}