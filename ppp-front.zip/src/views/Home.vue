<template>
  <div class="home">
    <div class="chart-wrapper">
        <div class="origin-data-chart">
            <vue-echarts
                :options = "options"
            />
        </div>
        <div>
            <wave-filter></wave-filter>
        </div>
    </div>
  </div>
</template>

<script>
  import { ref, onMounted} from 'vue'
  import VueEcharts from '../components/VueEcharts/VueEcharts'
  import WaveFilter from '../components/WaveFilter/WaveFilter'
  import { getData } from '../api/index.js'

  export default {
    name: 'Home',
    components: {
      VueEcharts,
      WaveFilter
    },
    setup(){
      const options = ref({})
      
      const update = (data) => {
        function createOption(){
            let xAxisData = []
            let pppData = []
            data.forEach(item => {
                xAxisData.push(item['DATE'])
                pppData.push(item['HEIGHT'])
            });
            return {
                xAxisData,pppData
            }
        }
        const legendData = ['原始数据']
        const {xAxisData,pppData}  = createOption()
        options.value = {
            title:{
                text:'潮位原始观测数据',
                textAlign:'auto',
                left:'40%',
            },
            xAxis: {
                type: 'category',
                name:'时间',
                nameGap:20,
                axisLine:{
                    show:true,
                    symbol:['none','arrow'],
                    symbolOffset : [0,12],
                    lineStyle:{
                        color:'#333',
                    }
                },
                axisLabel:{
                    rotate:-60
                },
                splitLine:{
                    show:true
                },
                axisPointer:{
                    show:true
                },
                axisTick:{
                    alignWithLabel : true
                },
                data:xAxisData
            },
            yAxis: {
                type: 'value',
                name:'潮位',
                // min:600,
                // max:1500,
                axisLine:{
                    show:true,
                    symbol:['none','arrow'],
                    symbolOffset : [0,12]
                },
                splitLine:{
                    show:true
                },
            },
            toolbox:{
                show:true,
                right:'10%',
                feature:{
                    dataZoom:{
                        show:true
                    },
                    saveAsImage:{
                        show:true,
                        type:'png',
                    },
                }
            },
            tooltip:{
                show:true,
                axisPointer:{
                    type:'cross'
                }
            },
            dataZoom:[{
                type:'slider',
                show:true,
                xAxisIndex:[0],
                start:1,
                end:35
            }],
            legend: {
                // Try 'horizontal'
                orient: 'vertical',
                right: 10,
                top: 'center',
                icon: 'circle',
                // data: ['原始数据','S-G滤波','小波滤波']
                data:legendData
            },
            series: [
                {
                    name:'原始数据',
                    type: 'line',
                    smooth: true,
                    data: pppData
                }
            ]
        }
      }
      onMounted(()=>{
        getData().then(data => {
          update(data.data)
        })
      })
      return {
        options
      }
    }
  }
</script>
<style lang="scss" scoped>
    body {
      width: 100%;
      height: 100%;
    }
    .chart-wrapper{
        display: flex;
        flex-direction: row;
    }
    .origin-data-chart {
      width: 800px;
      height: 400px;
    }
</style>